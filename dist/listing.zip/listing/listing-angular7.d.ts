/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { ApiService as ɵa } from './lib/api.service';
export { DemoMaterialModule as ɵc } from './lib/materialmodules';
export { YoutubeplayerComponent as ɵb } from './lib/youtubeplayer/youtubeplayer.component';
