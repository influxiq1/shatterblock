export declare class ListingService {
    constructor();
}
